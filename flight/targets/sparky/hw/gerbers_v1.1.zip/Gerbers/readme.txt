Sparky.GBL - bottom copper
Sparky.GBS - bottom soldermask
Sparky.GM1 - mechanical cutout
Sparky.GTL - top copper
Sparky.GTO - top overlay
Sparky.GTP - stencil
Sparky.GTS - top slodermask
Sparky.TXT - drill map
