GBL - bottom copper
GBS - bottom solder mask
GM1 - mechanical cutout
GTL - top copper
GTO - top overlay
GTS - top solder
TXT - NC drill
